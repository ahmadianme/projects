<?php

Autoloader::map(array(
    'jDateTime' => __DIR__ . '/libraries/jdatetime.php',
	'jDate'     => __DIR__ . '/libraries/jdate.php',
));